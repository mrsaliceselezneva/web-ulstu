import "./rating.scss"

const Rating = () => {
    return(
        <div className="rating_container">
            rating
        </div>
    )
}

export default Rating