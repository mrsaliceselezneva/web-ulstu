import "./visit.scss"


const Visit = () => {
    return(
        <div className="visit_container">
            hello
        </div>
    )
}

export default Visit