import './productive.scss'

const Productive = () => {
    return(
        <div className="producrive_contaier">
           hello
        </div>
    )
}

export default Productive