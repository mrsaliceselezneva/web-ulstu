import './MyProjects.scss';

function Projects(){
    return(
        <div></div>
    );
}

export default Projects;
