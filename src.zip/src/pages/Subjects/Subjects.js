
import './Subjects.scss';

function Subjects() {
    return (
        <div></div>

    );
}

export default Subjects;
