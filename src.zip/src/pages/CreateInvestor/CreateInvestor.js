import './CreateInvestor.scss';
import { FiPlusCircle, FiLayout, FiToggleLeft, FiToggleRight } from 'react-icons/fi';

function CreateInvestor(){
    return(
       <div className='create-investor'>
           <div>
               
           </div>
       </div>
    );
}

export default CreateInvestor;
