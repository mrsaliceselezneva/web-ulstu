import axios from "axios";

axios.defaults.baseURL = 'http://localhost:9999';

export default axios;