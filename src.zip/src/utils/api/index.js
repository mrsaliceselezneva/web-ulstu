export { default as dialogsAPI } from "./dialogs"
export { default as messagesAPI } from "./messages"